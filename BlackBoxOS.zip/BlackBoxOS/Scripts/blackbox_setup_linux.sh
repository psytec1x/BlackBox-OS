#!/bin/bash

echo "=================================="
echo "   BlackBox OS Setup (Linux)"
echo "=================================="
echo ""

# ========================
# Benutzerkonfiguration
# ========================
USB_DRIVE="/dev/sdX"  # USB-Gerät anpassen, z.B. /dev/sdb
VENTOY_DIR="Bootloader/ventoy"
TOOLS_DIR="Tools"
GUI_DIR="GUI"
MOUNT_POINT="/mnt/usb"

# ========================
# 1. Ventoy installieren
# ========================
echo "[1/3] Installiere Ventoy..."
if [ ! -d "$VENTOY_DIR" ]; then
    echo "Ventoy-Verzeichnis nicht gefunden! Stelle sicher, dass 'Bootloader/ventoy' existiert."
    exit 1
fi

if [ ! -b "$USB_DRIVE" ]; then
    echo "Ungültiges USB-Gerät: $USB_DRIVE. Bitte prüfen!"
    exit 1
fi

cd $VENTOY_DIR
sudo ./Ventoy2Disk.sh -i $USB_DRIVE
if [ $? -ne 0 ]; then
    echo "Ventoy-Installation fehlgeschlagen!"
    exit 1
fi

# ========================
# 2. Tools herunterladen
# ========================
echo "[2/3] Lade Tools herunter..."

mkdir -p $TOOLS_DIR/Network $TOOLS_DIR/WiFi $TOOLS_DIR/Forensic $TOOLS_DIR/Cracking

# Netzwerktools
echo "Lade SQLMap herunter..."
git clone https://github.com/sqlmapproject/sqlmap.git $TOOLS_DIR/Network/sqlmap
echo "Lade BeEF herunter..."
git clone https://github.com/beefproject/beef.git $TOOLS_DIR/Network/beef

# WLAN-Hacking
echo "Lade Aircrack-ng herunter..."
git clone https://github.com/aircrack-ng/aircrack-ng.git $TOOLS_DIR/WiFi/aircrack-ng

# Cracking
echo "Lade John the Ripper herunter..."
git clone https://github.com/openwall/john.git $TOOLS_DIR/Cracking/john

# Forensik
echo "Lade Volatility herunter..."
git clone https://github.com/volatilityfoundation/volatility3.git $TOOLS_DIR/Forensic/volatility

# ========================
# 3. GUI einrichten
# ========================
echo "[3/3] Richte GUI ein..."

sudo apt update
sudo apt install -y nodejs npm

mkdir -p $GUI_DIR
cd $GUI_DIR

# Projekt initialisieren
npm init -y
npm install electron

# GUI-Dateien erstellen
echo "Erstelle GUI-Dateien..."
cat > main.js <<EOL
const { app, BrowserWindow } = require('electron');
let win;
app.on('ready', () => {
    win = new BrowserWindow({ width: 800, height: 600 });
    win.loadFile('index.html');
});
EOL

cat > index.html <<EOL
<!DOCTYPE html>
<html>
<head>
    <title>BlackBox OS</title>
</head>
<body style="background:black; color:green; font-family:monospace;">
    <h1>BlackBox OS</h1>
    <p>Willkommen im BlackBox OS Menü!</p>
</body>
</html>
EOL

echo "GUI erfolgreich eingerichtet!"

# ========================
# Abschluss
# ========================
echo "=================================="
echo "   BlackBox OS Setup abgeschlossen!"
echo "=================================="
