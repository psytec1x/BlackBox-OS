#!/bin/bash

echo "=========================="
echo "  BlackBox OS Installer"
echo "=========================="
echo ""

# Pfade und Parameter
USB_DRIVE="/dev/sdX"  # Benutzer muss das Zielgerät anpassen
MOUNT_POINT="/mnt/usb"
VENTOY_DIR="../Bootloader/ventoy"
TOOLS_DIR="../Tools"
GUI_DIR="../GUI"
ISO_DIR="../ISOs"

# USB-Drive überprüfen
if [ ! -b "$USB_DRIVE" ]; then
    echo "USB-Stick nicht gefunden. Bitte prüfen!"
    exit 1
fi

# Ventoy installieren
echo "Installiere Bootloader..."
cd $VENTOY_DIR
sudo ./Ventoy2Disk.sh -i $USB_DRIVE

# USB-Stick mounten
echo "Mounten des USB-Sticks..."
sudo mkdir -p $MOUNT_POINT
sudo mount ${USB_DRIVE}1 $MOUNT_POINT

# Dateien kopieren
echo "Kopiere Dateien..."
sudo cp -r $TOOLS_DIR $MOUNT_POINT/Tools
sudo cp -r $GUI_DIR $MOUNT_POINT/Menu
sudo cp -r $ISO_DIR $MOUNT_POINT/ISOs

# Unmounten und Abschluss
echo "Unmounting USB..."
sudo umount $MOUNT_POINT

echo "Einrichtung abgeschlossen!"
