#!/bin/bash

echo "=========================="
echo "  GUI Setup"
echo "=========================="
echo ""

# Node.js und Abhängigkeiten installieren
echo "Installiere Node.js und Electron..."
sudo apt update
sudo apt install -y nodejs npm

# GUI-Verzeichnis
GUI_DIR="GUI"
mkdir -p $GUI_DIR
cd $GUI_DIR

# Projekt initialisieren
echo "Initialisiere GUI-Projekt..."
npm init -y
npm install electron

# Standarddateien erstellen
echo "Erstelle GUI-Dateien..."
cat > main.js <<EOL
const { app, BrowserWindow } = require('electron');
let win;
app.on('ready', () => {
    win = new BrowserWindow({ width: 800, height: 600 });
    win.loadFile('index.html');
});
EOL

cat > index.html <<EOL
<!DOCTYPE html>
<html>
<head>
    <title>BlackBox OS Menu</title>
</head>
<body style="background:black; color:green;">
    <h1>BlackBox OS</h1>
</body>
</html>
EOL

echo "GUI erfolgreich eingerichtet!"
