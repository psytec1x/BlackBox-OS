#!/bin/bash

echo "=========================="
echo "  Ventoy Installation"
echo "=========================="
echo ""

# Pfad zur Ventoy-Installation
VENTOY_DIR="Bootloader/ventoy"
USB_DRIVE="/dev/sdX"  # Ersetze sdX mit dem korrekten Laufwerksnamen

# Überprüfen, ob Ventoy existiert
if [ ! -d "$VENTOY_DIR" ]; then
    echo "Ventoy-Verzeichnis nicht gefunden. Stelle sicher, dass 'Bootloader/ventoy' existiert."
    exit 1
fi

# Laufwerk überprüfen
if [ ! -b "$USB_DRIVE" ]; then
    echo "Kein gültiger USB-Stick gefunden. Bitte überprüfe den Pfad!"
    exit 1
fi

# Installation starten
cd $VENTOY_DIR
sudo ./Ventoy2Disk.sh -i $USB_DRIVE
if [ $? -ne 0 ]; then
    echo "Ventoy konnte nicht installiert werden. Bitte überprüfe die Logs."
    exit 1
fi

echo "Ventoy erfolgreich installiert!"
