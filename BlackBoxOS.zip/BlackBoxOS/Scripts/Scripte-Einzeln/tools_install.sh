#!/bin/bash
mkdir -p ../Tools/Network ../Tools/WiFi ../Tools/Forensic ../Tools/Cracking

# Netzwerktools
git clone https://github.com/sqlmapproject/sqlmap.git ../Tools/Network/sqlmap
git clone https://github.com/beefproject/beef.git ../Tools/Network/beef

# WLAN-Hacking
git clone https://github.com/aircrack-ng/aircrack-ng.git ../Tools/WiFi/aircrack-ng

# Cracking
git clone https://github.com/openwall/john.git ../Tools/Cracking/john

# Forensik
git clone https://github.com/volatilityfoundation/volatility3.git ../Tools/Forensic/volatility
