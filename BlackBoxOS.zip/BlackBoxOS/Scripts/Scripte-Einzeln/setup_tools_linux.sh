#!/bin/bash

echo "=========================="
echo "  Tools Download & Setup"
echo "=========================="
echo ""

# Tool-Verzeichnisse erstellen
mkdir -p Tools/Network Tools/WiFi Tools/Forensic Tools/Cracking

# Netzwerktools
echo "Lade SQLMap herunter..."
git clone https://github.com/sqlmapproject/sqlmap.git Tools/Network/sqlmap
echo "Lade BeEF herunter..."
git clone https://github.com/beefproject/beef.git Tools/Network/beef

# WLAN-Hacking
echo "Lade Aircrack-ng herunter..."
git clone https://github.com/aircrack-ng/aircrack-ng.git Tools/WiFi/aircrack-ng

# Cracking
echo "Lade John the Ripper herunter..."
git clone https://github.com/openwall/john.git Tools/Cracking/john

# Forensik
echo "Lade Volatility herunter..."
git clone https://github.com/volatilityfoundation/volatility3.git Tools/Forensic/volatility

echo "Alle Tools wurden erfolgreich heruntergeladen!"
